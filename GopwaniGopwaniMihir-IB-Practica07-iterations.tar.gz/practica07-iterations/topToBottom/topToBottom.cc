/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Mihir Mahesh Gopwani Gopwani 
 * @date Nov 2 2023
 * @brief este programa lee dos numeros y imprime los numeros entre esos parametros
*/
#include<iostream>
int main () {
  int num;
    std::cout<< "escribe un numero: ";
    std::cin >> num;
    
  int num2;
    std::cout<< "escribe otro numero: ";
    std::cin >> num2;
      
     for (int i; i < num; i++) {
       std::cout<< num;

  }
return 0;
}

