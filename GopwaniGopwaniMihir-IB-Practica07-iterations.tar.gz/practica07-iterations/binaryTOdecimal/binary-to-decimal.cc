/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Mihir Mahesh Gopwani Gopwani
 * @date Oct 27 2023
 * @brief Este codigo pide un numero en binario y lo convierte en decimal
*/
#include<iostream>
#include<cmath>
int main () {
  int binario;
    std::cout<< "Escribe un numero en binario :";
    std::cin>>binario;
    int bin[10]    
    int exp = 0
    for (int i = bin.size() -1; i > 0 ; --i) {
      result +=bin[i]*pow(2,exp);
      ++exp;
    }
  return 0;
}
  	

